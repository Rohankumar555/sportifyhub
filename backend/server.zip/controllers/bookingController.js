const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const Booking = require('../models/booking');  // Import models
const Center = require('../models/center');
const Sports = require('../models/sport');

dotenv.config();  

 
const app = express();

app.use(bodyParser.json());

// Connect to MongoDB
require("../connection/db")


const getBooking= async (req, res) => {       //{/api/bookings/:centerId/:date}       // View all bookings for a center on a given day
    try {
        const { centerId, date } = req.params;
        const bookings = await Booking.find({
            center_id: centerId,
            date: new Date(date)
        }).populate('sport_id', 'name');

        const groupedBookings = bookings.reduce((acc, booking) => {
            if (!acc[booking.hour_slot]) {
                acc[booking.hour_slot] = [];
            }
            acc[booking.hour_slot].push({
                court: booking.court_number,
                sport: booking.sport_id.name,
                booked_by: booking.booked_by
            });
            return acc;
        }, {});

        res.json(groupedBookings);
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
};


const createBooking = async (req, res) => {  // {/api/bookings}
    try {
        const { center_id, sport_id, court_number, date, hour_slot, booked_by } = req.body;

        // Validate required fields
        if (!center_id || !sport_id || !court_number || !date || !hour_slot || !booked_by) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        
        // Create new booking
        const newBooking = new Booking({
            center_id,
            sport_id,
            court_number,
            date: new Date(date),
            hour_slot,
            booked_by // Add name of the person booking
        });

        await newBooking.save();
        res.status(201).json(newBooking);
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
};


module.exports={getBooking,createBooking};
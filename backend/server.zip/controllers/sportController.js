const express = require('express');
const app = express();
const Booking = require('../models/booking');  // Import models
const Center = require('../models/center');
const Sports = require('../models/sport');

const getSport= async (req, res) => {                // View all sports
    try {
        const sports = await Sports.find();
        res.json(sports);
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
};


const createSport=async (req, res) => {                   // Create a new sport
    try {
        const { name, courts } = req.body;
        const newSport = new Sports({ name, courts });
        await newSport.save();
        res.status(201).json(newSport);
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
};

module.exports={getSport,createSport};

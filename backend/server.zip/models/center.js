// models/Center.js
const mongoose = require('mongoose');

const centerSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        unique: true
    },
    sports: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Sports'
    }]
});

module.exports = mongoose.model('Center', centerSchema);

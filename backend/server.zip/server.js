const express=require("express");
const app=express();
const  hbs = require("hbs");
const bodyParser = require('body-parser');
const cookieParser = require("cookie-parser");
const path=require("path");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());  //app to use cookie parser
app.use(express.json());
app.use(express.urlencoded({extended:false}));
const static_path=path.join(__dirname,"./public");
const template_path=path.join(__dirname,"../templates");
app.use(express.static(static_path));
require("./connection/db");
app.set("view engine","hbs");
app.set("views",template_path);


const bookingController=require("./controllers/bookingController");
const sportController=require("./controllers/sportController");
const centerController=require("./controllers/centerController");
const loginController=require("./controllers/loginController");

const port=5050;

// Routes for bookings
 app.get('/bookings/:centerId/:date', bookingController.getBooking);
 app.post('/api/bookings', bookingController.createBooking);

// Routes for centers
app.get('/centers/:centerId/sports', centerController.getSportsByCenter);
app.post('/centers', centerController.createCenter);

// // Routes for sports
app.get('/sports', sportController.getSport);
app.post('/sports', sportController.createSport);
app.get('/',(req,res)=>{
    res.render("index");
})

app.get('/login',(req,res)=>{
    res.render("login");
})
app.post('login',loginController.signup);

app.get('/booking',(req,res)=>{
    res.render("booking");
})

app.listen(port,(error)=>{
    if(error){
        console.log(error);
    }
    console.log("Server is running at "+port);
})
